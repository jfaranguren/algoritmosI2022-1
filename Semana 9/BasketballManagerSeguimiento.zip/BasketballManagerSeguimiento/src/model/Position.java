package model;

public enum Position {

	CENTER, POWER_FORWARD, SMALL_FORWARD, POINT_GUARD, SHOOTING_GUARD
	
}
